﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class ProductDetailVariationOption
    {
        public long OptionId { get; set; }

        public string OptionName { get; set; }

        public string Value { get; set; }
    }
}
