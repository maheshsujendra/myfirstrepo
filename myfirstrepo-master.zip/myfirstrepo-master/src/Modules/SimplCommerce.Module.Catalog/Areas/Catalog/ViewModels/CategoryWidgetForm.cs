﻿using SimplCommerce.Module.Core.Areas.Core.ViewModels;

namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class CategoryWidgetForm : WidgetFormBase
    {
        public CategoryWidgetSettings Settings { get; set; }
    }
}
