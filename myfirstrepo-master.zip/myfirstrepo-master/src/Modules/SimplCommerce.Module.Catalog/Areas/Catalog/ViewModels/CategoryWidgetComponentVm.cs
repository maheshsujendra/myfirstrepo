﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class CategoryWidgetComponentVm
    {
        public long Id { get; set; }

        public string WidgetName { get; set; }

        public CategoryThumbnail Category { get; set; }
    }
}
