﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class ProductCategoryForm
    {
        public long Id { get; set; }

        public bool IsFeaturedProduct { get; set; }

        public int DisplayOrder { get; set; }
    }
}
