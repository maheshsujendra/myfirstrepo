﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class FilterPrice
    {
        public decimal MaxPrice { get; set; }

        public decimal MinPrice { get; set; }
    }
}
