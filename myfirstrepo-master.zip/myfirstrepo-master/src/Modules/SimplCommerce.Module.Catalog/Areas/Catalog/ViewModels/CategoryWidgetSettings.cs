﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class CategoryWidgetSettings
    {
        public long CategoryId { get; set; }
    }
}
