﻿using SimplCommerce.Module.Core.Models;

namespace SimplCommerce.Module.Cms.Models
{
    public class Page : Content
    {
        public string Body { get; set; }
    }
}
