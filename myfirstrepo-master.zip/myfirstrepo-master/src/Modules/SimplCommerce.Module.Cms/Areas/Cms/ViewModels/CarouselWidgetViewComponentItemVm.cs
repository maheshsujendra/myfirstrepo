﻿namespace SimplCommerce.Module.Cms.Areas.Cms.ViewModels
{
    public class CarouselWidgetViewComponentItemVm
    {
        public string Image { get; set; }

        public string Caption { get; set; }

        public string SubCaption { get; set; }

        public string LinkText { get; set; }

        public string TargetUrl { get; set; }
    }
}
