﻿using SimplCommerce.Module.Core.Areas.Core.ViewModels;

namespace SimplCommerce.Module.Cms.Areas.Cms.ViewModels
{
    public class HtmlWidgetForm : WidgetFormBase
    {
        public string HtmlContent { get; set; }
    }
}
