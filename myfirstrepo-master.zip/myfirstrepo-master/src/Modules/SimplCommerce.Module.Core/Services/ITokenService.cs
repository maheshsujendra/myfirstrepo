﻿using System.Collections.Generic;
using System.Security.Claims;

namespace SimplCommerce.Module.Core.Services
{
    public interface ITokenService
    {
        string GenerateAccessToken(IEnumerable<Claim> claims);

        string GenerateRefreshToken();

        ClaimsPrincipal GetPrincipalFromExpiredToken(string token);
    }
}
