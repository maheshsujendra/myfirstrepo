﻿namespace SimplCommerce.Module.Core.Areas.Core.ViewModels.Manage
{
    public class DefaultAddressViewComponentVm
    {
        public UserAddressListItem Address { get; set; }
    }
}
