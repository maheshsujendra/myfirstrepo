﻿namespace SimplCommerce.Module.Core.Models
{
    public enum MediaType
    {
        Image = 1,

        File = 5,

        Video = 10,
    }
}
